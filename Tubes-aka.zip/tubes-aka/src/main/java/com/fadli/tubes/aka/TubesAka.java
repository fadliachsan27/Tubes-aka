package com.fadli.tubes.aka;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class TubesAka {

    static ArrayList<String> inventory = new ArrayList<>();

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> createAndShowGUI());
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("Manajemen Inventaris Toko Elektronik");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 1, 10, 10));

        JLabel titleLabel = new JLabel("=== Manajemen Inventaris Toko Elektronik ===", JLabel.CENTER);
        panel.add(titleLabel);

        JButton addIterativeButton = new JButton("Tambahkan Barang (Iteratif)");
        addIterativeButton.addActionListener(e -> addItemsIterativeMenu());
        panel.add(addIterativeButton);

        JButton addRecursiveButton = new JButton("Tambahkan Barang (Rekursif)");
        addRecursiveButton.addActionListener(e -> addItemsRecursiveMenu());
        panel.add(addRecursiveButton);

        JButton viewInventoryButton = new JButton("Lihat Inventaris");
        viewInventoryButton.addActionListener(e -> displayInventory());
        panel.add(viewInventoryButton);

        JButton analyzePerformanceButton = new JButton("Analisis Performa");
        analyzePerformanceButton.addActionListener(e -> analyzePerformance());
        panel.add(analyzePerformanceButton);

        JButton exitButton = new JButton("Keluar");
        exitButton.addActionListener(e -> System.exit(0));
        panel.add(exitButton);

        frame.add(panel);
        frame.setVisible(true);
    }

    private static void addItemsIterativeMenu() {
        String input = JOptionPane.showInputDialog("Masukkan jumlah barang yang ingin ditambahkan (Iteratif):");
        if (input != null && !input.isEmpty()) {
            try {
                int n = Integer.parseInt(input);
                for (int i = 0; i < n; i++) {
                    String itemName = JOptionPane.showInputDialog("Masukkan nama barang ke-" + (i + 1) + ":");
                    if (itemName != null && !itemName.isEmpty()) {
                        inventory.add(itemName);
                    } else {
                        JOptionPane.showMessageDialog(null, "Nama barang tidak boleh kosong.");
                        i--; // Retry for the same index
                    }
                }
                JOptionPane.showMessageDialog(null, n + " barang telah ditambahkan menggunakan algoritma iteratif.");
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Input tidak valid. Harap masukkan angka.");
            }
        }
    }

    private static void addItemsRecursiveMenu() {
        String input = JOptionPane.showInputDialog("Masukkan jumlah barang yang ingin ditambahkan (Rekursif):");
        if (input != null && !input.isEmpty()) {
            try {
                int n = Integer.parseInt(input);
                addItemsRecursive(n, 0);
                JOptionPane.showMessageDialog(null, n + " barang telah ditambahkan menggunakan algoritma rekursif.");
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Input tidak valid. Harap masukkan angka.");
            }
        }
    }

    private static void addItemsRecursive(int n, int count) {
        if (count < n) {
            String itemName = JOptionPane.showInputDialog("Masukkan nama barang ke-" + (count + 1) + ":");
            if (itemName != null && !itemName.isEmpty()) {
                inventory.add(itemName);
                addItemsRecursive(n, count + 1);
            } else {
                JOptionPane.showMessageDialog(null, "Nama barang tidak boleh kosong.");
                addItemsRecursive(n, count); // Retry for the same count
            }
        }
    }

    private static void displayInventory() {
        if (inventory.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Inventaris kosong.");
        } else {
            StringBuilder inventoryList = new StringBuilder("Daftar Inventaris:\n");
            for (String item : inventory) {
                inventoryList.append(item).append("\n");
            }
            JOptionPane.showMessageDialog(null, inventoryList.toString());
        }
    }

private static void analyzePerformance() {
    int[] inputSizes = {1, 10, 100, 1000};
    StringBuilder result = new StringBuilder("\n=== Analisis Performa ===\nUkuran Input | Iteratif (μs) | Rekursif (μs)\n");

    for (int n : inputSizes) {
        // Iteratif
        ArrayList<String> tempInventory = new ArrayList<>();
        long startIterative = System.nanoTime();
        for (int i = 0; i < n; i++) {
            tempInventory.add("Barang Iteratif " + (i + 1));
        }
        long endIterative = System.nanoTime();
        long iterativeTime = (endIterative - startIterative) / 1000; // Convert to microseconds (μs)

        // Rekursif
        tempInventory.clear();
        long startRecursive = System.nanoTime();
        addItemsRecursiveTest(tempInventory, n, 0);
        long endRecursive = System.nanoTime();
        long recursiveTime = (endRecursive - startRecursive) / 1000; // Convert to microseconds (μs)

        result.append(String.format("%12d | %12d | %12d\n", n, iterativeTime, recursiveTime));
    }

    result.append("\nCatatan: Waktu eksekusi dalam mikrodetik (μs).\nIteratif cenderung lebih cepat karena overhead fungsi rekursif.");
    JOptionPane.showMessageDialog(null, result.toString());
}

// Versi rekursif khusus untuk analisis performa
private static void addItemsRecursiveTest(ArrayList<String> tempInventory, int n, int count) {
    if (count < n) {
        tempInventory.add("Barang Rekursif " + (count + 1));
        addItemsRecursiveTest(tempInventory, n, count + 1);
    }
}

}
